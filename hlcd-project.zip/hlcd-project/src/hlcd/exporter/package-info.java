/**
 * Takes care of exporting the code found to {@code .bin}, {@code .tex} and
 * {@code .m} (Matlab) file.
 */
package hlcd.exporter;