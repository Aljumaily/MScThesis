/**
 * A tester package where the program is executed and the output is exported
 * as a {@code .m} file to compare the results with Matlab.
 */
package hlcd.testing.matlabChecker;