/**
 * The tests used to help in implementing and testing
 * {@link hlcd.operations.LongArray}.
 */
package hlcd.testing.arrayTester;