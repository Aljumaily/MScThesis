/**
 * A tester package checking the optimizations of the bit manipulation
 * operations of constant time used in this program yield the same output as
 * the slower operations that use loops.
 */
package hlcd.testing.optimizationTester;