/**
 * Contains the enums used in this program.
 */
package hlcd.enums;