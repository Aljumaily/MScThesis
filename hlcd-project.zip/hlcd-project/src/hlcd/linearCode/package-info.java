/**
 * Contains the mathematical definition of a "code" along with a validator to
 * ensure the code obtained is valid.
 */
package hlcd.linearCode;