/**
 * The customized exceptions thrown in this program are found here.
 */
package hlcd.exceptions;