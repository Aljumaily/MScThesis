/**
 * Dedicated for the execution of the program by using
 * {@link hlcd.run.SimpleExecutor}, {@link hlcd.run.ComplexExecutor} or
 * {@link hlcd.run.ListExecutor}.
 */
package hlcd.run;