/**
 * A package created to find optimal Hermitian Linear Complementary Dual
 * Quaternary Codes.
 */
package hlcd;