/**
 * The bundle of wrapper classes for the different available parameters that
 * can be used in this program.
 */
package hlcd.parameters;