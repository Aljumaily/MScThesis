/**
 * The tools used when searching for a code are found here.
 */
package hlcd.operations;