For a fully detailed breakdown of this project, please refer to:
https://github.com/Aljumaily/MScThesis